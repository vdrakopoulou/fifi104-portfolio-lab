# FIFI104 | 100-Stock Portfolio Lab

Prof. Veliota Drakopoulou

A browser-based paper-portfolio exercise: investigate companies, allocate a budget, test hypothetical scenarios, compare designs and defend an investment argument.

## Students: open the published website

Use the live GitHub Pages link shared by your instructor. Opening `index.html` inside GitHub's file browser displays code, not the working lab.

**Instructor:** after publishing, add your actual live lab link here. The following is a URL pattern, not an active address:

`https://YOUR-USERNAME.github.io/fifi104-portfolio-lab/`

Read [STUDENT_GUIDE.md](STUDENT_GUIDE.md) for the practice workflow.

**Save work with Save lab file before refreshing or closing.** Load the downloaded JSON to resume. No student account is required to use this public lab; work is not automatically submitted, synchronized or graded.

## Instructor: browser-only setup

1. Create or sign in to your personal GitHub account, verify your email and configure two-factor authentication.
2. Create a repository named `fifi104-portfolio-lab`. For the GitHub Free setup, use **Public** visibility and turn **Add README** on.
3. Extract the supplied ZIP. In the repository, choose **Add file > Upload files**. Upload `index.html`, `README.md` and `STUDENT_GUIDE.md` directly to the repository's top level. The supplied README replaces the initial one. Do not upload the ZIP itself or nest the files inside another folder. Commit the files to `main`.
4. Open **Settings > Pages**. Under **Build and deployment**, choose **Source: Deploy from a branch**, **Branch: main**, and **Folder: /(root)**. Click **Save**.
5. Once the Pages deployment reports success, open **Settings > Pages > Visit site** and copy the published address. No custom domain is needed.
6. Test that address in a private/incognito window, then share it through your course platform or email. Add the live link to this README.

If the repository uses a default branch name other than `main`, select the branch containing the uploaded files. The entry file must be named exactly `index.html` and be at the top level of the selected publishing folder.

## Files in this repository

- `index.html`: the supplied lab, copied without changes and named as the site's entry page.
- `README.md`: hosting and course-access instructions.
- `STUDENT_GUIDE.md`: practice, saving and submission instructions.

There is no package installation, server application, API key or separate database to configure for this supplied static lab.

## Public access and data handling

This setup makes the website and repository public, not restricted to enrolled students. Publish only material you are permitted to share. Do not upload student names, grades, saved submissions, credentials, private documents or API keys. Students do not need collaborator access or the instructor's login to practice.

Use your institution's approved private submission channel for assessed work. GitHub Pages hosting does not add automatic saving, a gradebook or an assignment collection system to this lab. GitHub records visitor IP addresses for security purposes.

## Updating the lab

Upload the replacement `index.html` to the same location and commit it to the publishing branch. After the deployment succeeds, test the live page. The site address remains the same when the account and repository names are unchanged. Have students save their work before reloading.

Retain a dated local copy of each teaching version. This lab's JSON importer checks its schema, source date and ticker fields; older saves may be rejected if these change. The fixed data snapshot does not update itself when the site is hosted online.

## Data and exercise boundaries

The supplied lab labels its entry-price snapshot **24 September 2026** and identifies the issuer holdings source in its Evidence section. These source labels and all calculations are preserved, not independently reverified by this hosting package. All scenario price changes are hypothetical. This is educational paper practice, not live trading or investment advice.

The original five-stock exercise is embedded separately in the supplied file. Its period and rules are not interchangeable with the 100-stock scenario exercise.

## Official GitHub setup references

- [Create an account](https://docs.github.com/en/account-and-profile/how-tos/account-management/creating-an-account-on-github)
- [Create a repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)
- [Upload files](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
- [Configure Pages publishing](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
- [Create and view a Pages site](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [About Pages, website addresses and visit logs](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)
